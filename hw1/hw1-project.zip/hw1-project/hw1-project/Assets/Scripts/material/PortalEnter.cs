using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class PortalEnter : MonoBehaviour
{
    public Transform backPortal;

    private bool isPortal;//�ж��ǲ�����
    private Transform playerTransform;
    private Vector2 move;
    // Start is called before the first frame update
    void Awake()
    {
        playerTransform = GameObject.Find("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (isPortal)
            {
                playerTransform.position = backPortal.position;
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.name == "Player")
        {
            isPortal = true;
            UnityEngine.Debug.Log("Enter");
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            isPortal = false;
        }
    }

}
