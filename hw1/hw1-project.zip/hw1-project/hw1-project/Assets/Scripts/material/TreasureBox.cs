using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreasureBox : MonoBehaviour
{
    private bool canOpen;
    private bool canClose;
    private Animator anim;
    public GameObject portalEnter;
    public GameObject portalExit;

    void Awake()
    {
        anim = GetComponent<Animator>();
        canClose = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (canOpen&&!canClose)
            {
                anim.SetTrigger("Opening");
                canClose = true;
                portalEnter.SetActive(true);
                portalExit.SetActive(true);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.name == "Player")
        {
            canOpen = true;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            canOpen = false;
        }
    }
}
