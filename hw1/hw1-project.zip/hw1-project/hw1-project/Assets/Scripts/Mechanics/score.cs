using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class score : MonoBehaviour
{
    public TextMeshProUGUI ScoreText;
    public int runtime = 0;
    public int starttime = 0;
    public int scorenum = -1;
    // Start is called before the first frame update
    void Awake()
    {
        ScoreText = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {

        //ScoreText.text = "Score: " + scorenum + "   Time: " + runtime;
    }
}
