using System.Collections;
using System.Collections.Generic;
//using Platformer.Mechanics;
using UnityEngine;

public class RestartButton : MonoBehaviour
{
    public GameObject Player;
    private Platformer.Mechanics.PlayerController otherScript; //��namespace��Ҫ����ǰ׺
    public int temptime = 0;
    //public PlayerController playerController;
    void awake()
    {
        
    }
    
    public void OnClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(0);
        Player = GameObject.Find("Player");
        otherScript = Player.GetComponent<Platformer.Mechanics.PlayerController>();
        temptime = otherScript.runtime;
        //playerController.starttime = playerController.runtime;
        
    }
}
